import React, { Component } from "react";


class HenaFam extends Component {
  

  render() {
    return (
     <div>
         <h1>Hello</h1>
     </div>
    );
  }
}

export default HenaFam;