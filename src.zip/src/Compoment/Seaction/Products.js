import React, { Component } from 'react'
import {Link} from 'react-router-dom'
import {DataContext} from './Context'
import '../Css/Products.css'
import Button from '@material-ui/core/Button';
import Typography from '@material-ui/core/Typography';
import { Grid, Paper, makeStyles } from '@material-ui/core';
import Input from '@material-ui/core/Input';
import Rating from '@material-ui/lab/Rating';
import Accordion from '@material-ui/core/Accordion';
import AccordionSummary from '@material-ui/core/AccordionSummary';
import AccordionDetails from '@material-ui/core/AccordionDetails';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import Slider from '@material-ui/core/Slider';
import IconButton from '@material-ui/core/IconButton';
import ShareIcon from '@material-ui/icons/Share';
//import BuyNow from './Compoment/BuyNow';
import SearchIcon from '@material-ui/icons/Search';
import TextField from '@material-ui/core/TextField';
import InputAdornment from '@material-ui/core/InputAdornment';
import poultryService from '../../services/poultry.service';
import FeedbackIcon from '@material-ui/icons/Feedback';
import CloseIcon from '@material-ui/icons/Close';
import TableFooter from '@material-ui/core/TableFooter';
import TablePagination from '@material-ui/core/TablePagination';
import TableRow from '@material-ui/core/TableRow';
import PropTypes from 'prop-types';
import { useTheme } from '@material-ui/core/styles';
import FirstPageIcon from '@material-ui/icons/FirstPage';
import KeyboardArrowLeft from '@material-ui/icons/KeyboardArrowLeft';
import KeyboardArrowRight from '@material-ui/icons/KeyboardArrowRight';
import LastPageIcon from '@material-ui/icons/LastPage';


const useStyles1 = makeStyles((theme) => ({
  root: {
    flexShrink: 0,
    marginLeft: theme.spacing(2.5),
  },
}));

function TablePaginationActions(props) {
  const classes = useStyles1();
  const theme = useTheme();
  const { count, page, rowsPerPage, onChangePage } = props;

  const handleFirstPageButtonClick = (event) => {
    onChangePage(event, 0);
  };

  const handleBackButtonClick = (event) => {
    onChangePage(event, page - 1);
  };

  const handleNextButtonClick = (event) => {
    onChangePage(event, page + 1);
  };

  const handleLastPageButtonClick = (event) => {
    onChangePage(event, Math.max(0, Math.ceil(count / rowsPerPage) - 1));
  };

  return (
    <div className={classes.root}>
      <IconButton
        onClick={handleFirstPageButtonClick}
        disabled={page === 0}
        aria-label="first page"
      >
        {theme.direction === 'rtl' ? <LastPageIcon /> : <FirstPageIcon />}
      </IconButton>
      <IconButton onClick={handleBackButtonClick} disabled={page === 0} aria-label="previous page">
        {theme.direction === 'rtl' ? <KeyboardArrowRight /> : <KeyboardArrowLeft />}
      </IconButton>
      <IconButton
        onClick={handleNextButtonClick}
        disabled={page >= Math.ceil(count / rowsPerPage) - 1}
        aria-label="next page"
      >
        {theme.direction === 'rtl' ? <KeyboardArrowLeft /> : <KeyboardArrowRight />}
      </IconButton>
      <IconButton
        onClick={handleLastPageButtonClick}
        disabled={page >= Math.ceil(count / rowsPerPage) - 1}
        aria-label="last page"
      >
        {theme.direction === 'rtl' ? <FirstPageIcon /> : <LastPageIcon />}
      </IconButton>
    </div>
  );
}

// TablePaginationActions.propTypes = {
//   count: PropTypes.number.isRequired,
//   onChangePage: PropTypes.func.isRequired,
//   page: PropTypes.number.isRequired,
//   rowsPerPage: PropTypes.number.isRequired,
// };


  
  const theme= {
    root: {
      flexGrow: 1,
      
    },
    paper: {
      // padding: theme.spacing(2),
      //textAlign: "center",
      width:430,
      marginLeft:30,
      // color: theme.palette.text.secondary,
      height:510
    },
    media: {
      height: 140,
    },
    input: {
      width: 42,
    },
    heading: {
      fontSize: 15,
      fontWeight: 20,
    },
    learnbutton: {
      marginLeft:0,
    },
    buybutton:{
      marginTop:0,
    },
    avathar:{
      textAlign:"right",
      backgroundColor:"black",
      width:55,
      height:55
    }
    
  }

export class Products extends Component {
   constructor (){
       super()
       this.state = {
           value:30,
           PoultryArr: [],
           page:0,
           rowsPerPage:6,
           count:0,
           searchName:"",
           minPrice:30,
           maxPrice:1200,
           ratting:''
        }
       
   }

   handleChangePage = (event, newPage) => {
    this.setState({
      page:newPage
    });
    poultryService.getAllPoultryInPage(newPage,6)
    .then((Response) => {
      this.setState({
        PoultryArr:Response.data.data,
        count:Response.data.TotalNoOfElements
       })
    })
  };

  onChange=(e) => {
    this.setState({
      ratting:e.target.value

    })
    console.log(e.target.value)
  } 

  handleChangeRowsPerPage = (event) => {
    //setRowsPerPage(parseInt(event.target.value, 10));
    this.setState ({
      page:0,
      rowsPerPage:event.target.value
    })
  };
  
  getAllPoultryInPage = () =>{
    poultryService.getAllPoultryInPage(this.state.page,6)
         .then((Response) => {
           this.setState({
             PoultryArr:Response.data.data,
             count:Response.data.TotalNoOfElements
            })
         })
  }


   handleSliderChange = (event, newValue) => {
     this.setState ({
           value:newValue
       })
      //  console.log(newValue)
    
  };


   filterData = () => {
    poultryService.getPoultrytByPriceBB(this.state.value,this.state.ratting)
    .then((Response) => {
         this.setState({PoultryArr:Response.data})
        console.log(Response)
})

  }

   handleInputChange = (event) => {
          //  if (event.target.value === '' ){
          //      this.setState({
          //          value:''
          //      }) 
          //      }
          //      else{
                this.setState({
                   value : event.target.value
               })
            // }
       
  };

   handleBlur = () => {
    // if (value < 35) {
    //   setValue(35);
    // } else if (value > 1000) {
    //   setValue(1000);
    // }
    this.setState ({
        value:1000
    })
  };
  componentDidMount(){
    this.reloadPoultryList();
  }
  searchPoultry =(e) =>{
    console.log("hellooooooooooo")
    this.setState({
      name:e.target.value
    })
    poultryService.searchPoultry(e.target.value)
    .then((Response) => {
      this.setState({PoultryArr:Response.data})
    })
}

  reloadPoultryList = () => {
    poultryService.getAllPoultryInPage(this.state.page,6)
    .then((Response) => {
      this.setState({
        PoultryArr:Response.data.data,
        count:Response.data.TotalNoOfElements
       })
      //  console.log(this.state.PoultryArr);
    })

       
  }
  onClearText=()=>{
    this.setState({
      name:""
    })
    this.reloadPoultryList()
  }
  


    static contextType = DataContext;

    render() {
        const {product,addCart} = this.context;
       
        return (
          <div style={{"padding":'20px',}}>
          <center>
            
         
          <TextField  onChange={this.searchPoultry}
                                value={this.state.name}
                                id="input-with-icon-textfield"
                                label="Search for Poultry"
                                variant="filled"
                                InputProps={{
                                    startAdornment: (
                                    <InputAdornment position="start">
                                        <IconButton type="submit" aria-label="search">
                                            <SearchIcon />
                                        </IconButton>
                                        {/* <IconButton  >
                                          < CloseIcon position="start" />
                                         </IconButton> */}
                                    </InputAdornment>
                                    
                                    ),
                                    endAdornment:(
                                      <InputAdornment position="end">
                                        <IconButton onClick={()=>this.onClearText()}>
                                        < CloseIcon />
                                        </IconButton>
                                    </InputAdornment>

                                    )
                                }}
                                />
                                {/* <IconButton  >
                                          < CloseIcon position="start" />
                                         </IconButton> */}
          </center>
      
    
         
          <div className="card2">
            <Grid container spacing = {1}> 
             <Grid item xs={2 }>
              
            <Paper style={{backgroundColor:"white",border:"none",borderColor:"white"}}>
      <Accordion>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1a-content"
          id="panel1a-header"
        >
          <Typography style={theme.heading}style={{fontFamily: 'Raleway',fontStyle: 'bold',fontSize:18}}>RATING</Typography>
        </AccordionSummary>
        <AccordionDetails>
          <Typography>
          
          {/* <Rating name="size-medium" onClick={()=> this.AddRatting ()} defaultValue={this.state.ratting} /><br/> */}

          <Rating
            name="simple-controlled"
            value={this.state.ratting}
            onChange={(event, newValue) => {
              console.log(newValue)
              this.setState({ ratting: newValue});
            }}
          /> 
          
          
          </Typography>
        </AccordionDetails>
      </Accordion>
        
      <Accordion>
        <AccordionSummary
          expandIcon={<ExpandMoreIcon />}
          aria-controls="panel1a-content"
          id="panel1a-header"
        >
          <Typography style={theme.heading}style={{fontFamily: 'Raleway',fontStyle: 'bold',fontSize:18}}>PRICE</Typography>
        </AccordionSummary>
        <AccordionDetails>
          <div style={{width:250}}>
                <Typography>
                {/* <Typography id="input-slider" gutterBottom>
              Volume
            </Typography> */}
            <Grid container spacing={2} alignItems="center">
              {/* <Grid item>
                <VolumeUp />
              </Grid> */}
              <Grid item xs>
                <Slider
                  //value={typeof this.value === 'number' ? this.value : 0}
                  value = {this.state.value}
                  onChange={this.handleSliderChange}
                  aria-labelledby="input-slider"
                  max="1000"
                />
              </Grid>
              <Grid item>
                <Input
                  style={{width:45}}
                  value={this.state.value}
                  margin="dense"
                  onChange={ this.handleInputChange}
                  // onBlur={this.handleBlur}
                  inputProps={{
                    //step: 10,
                    min: 35,
                    max: 1000,
                    type: 'number',
                    'aria-labelledby': 'input-slider',
                  }}
                />
                
              </Grid>
              
            </Grid>
      

          </Typography>
          </div>
        </AccordionDetails>
        
        </Accordion>
        <br/><br/><br/>
                            <Button variant="outlined" style={{backgroundColor:"#0d47a1",fontFamily:"Raleway",color:"white",width:"100px"}}type = "submit"onClick={()=>this.filterData()}>Find</Button>
      </Paper>
     
    
      </Grid>
      <Grid item xs={10 }>
            <div id="product" style={{display:"flex"}}>

              {this.state.PoultryArr && (
                // console.log("hi")
                // {
                  this.state.PoultryArr.map(product =>(
                     <div className="card" key={product.id}>
                       <div className="card1" key={product.id}>
                       <Grid container spacing = {1}>
                       <Grid item xs={10}>
                         
                        <h3 style={{color:"blue",fontFamily: 'Raleway',fontStyle: 'bold',fontSize:20}}>
                                  <Link to={`/product/${product.id}`}>{product.name}</Link>
                              </h3>
                              </Grid>
                              <Grid item xs={1}/>
                              <Grid item xs={1}>
                              <ShareIcon style={{alignItems:"self-end"}} />
                                </Grid>
                              </Grid>
                         <p>Available :{product.avilable}</p>

                    
                          <Link to={`/product/${product.id}`}>
                              <img src={product.url} alt=""/>
                          </Link><br/>
                          <div className="content">
                          <p style={{ textAlign:"center" }}>{product.describtion}</p>
                          
                          <div style={{display:"flex"}}> 
                          
                         
                          <Grid container spacing = {1}>
                          <Grid item xs={10}>
                          <Rating
                               name="simple-controlled"
                               value={product.ratting}
                               readOnly
                               // onChange={(event, newValue) => {
                               //   console.log(newValue)
                               //   this.setState({ ratting: newValue});
                               // }}
                             /> <br/> <br/>
                              <Button  href="" color="primary"variant="contained" onClick={()=> addCart(product.id)} style={{backgroundColor:"#0d47a1"}}><strong>
                                     Add to card
                                  </strong></Button>
                                 </Grid>
                                 {/* <Grid item xs={2}/> */}
                                 <Grid item xs={1}>
                                 <span style={{fontFamily: 'Raleway',fontStyle: 'bold',fontSize:24}}>{product.price}.Rs</span><br/><br/>
                                 <Button  href="BuyNow"  color="primary"variant="contained"style={{backgroundColor:"#0d47a1"}} ><strong>
                                BuyNow
                               </strong></Button>
                               <Button  href="AddFeedback"  color="primary"variant="contained"style={{backgroundColor:"#0d47a1"}} ><strong><FeedbackIcon style={{fontSize:20}}></FeedbackIcon></strong></Button>
                               </Grid>
                               </Grid>
                                 <Grid item xs={12}>

                     </Grid>
                     </div>
                    
                   
                          </div>
                      </div>
                      </div>
                  ))
              // }
              )}
              
               
            </div>
            </Grid>
            </Grid>  
            {/* </Grid>
            </Grid>  */}
             <TableFooter>
          <TableRow>
            <TablePagination
              // rowsPerPageOptions={[5, 10, 25, { label: 'All', value: -1 }]}
              // colSpan={3}
              count={this.state.count}
              rowsPerPage={this.state.rowsPerPage}
              page={this.state.page}
              SelectProps={{
                inputProps: { 'aria-label': 'rows per page' },
                native: true,
              }}
              onChangePage={this.handleChangePage}
              onChangeRowsPerPage={this.handleChangeRowsPerPage}
              ActionsComponent={TablePaginationActions}
            />
          </TableRow>
        </TableFooter>
            </div>
          </div>
            
        )
    }
}

export default Products