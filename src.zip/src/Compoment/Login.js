import React, {Component} from 'react';
import { Card, CardContent, Typography, Grid, FormControl, TextField, Button } from '@material-ui/core';
import Paper from '@material-ui/core/Paper';
import CardMedia from '@material-ui/core/CardMedia';
import Apic2 from './Apic2.jpg';





const style = {
    root:  {
        minWidth: 275,
        backgroundColor:'blue',
        //marginTop: 100,
        color: 'white',
        
         },
    paper: {
      textAlign: "center",
      width:400,
      marginLeft:50,
    },
     
    button: {
      

        marginTop:10,
        paddingTop:15,
        paddingBottom:15,
        marginLeft:30,
        marginRight:30,
        backgroundColor:'#00BCD4',
        borderRadius:20,
        borderWidth: 1,
        borderColor: '#fff',
        backgroundColor:"#926F34",
        width:250,
        height:45,
        
      },
    
         
}

export default class Login extends Component {
    constructor(props){
        super(props);

    this.state = {
      username: "",
      password: "",
      message: ""
      <CardMedia 
      <CardMedia 
    };
  }

  
render(){ 
    return (
      <div>
        <Paper style={{height:750,width:700,backgroundColor:"#e0e0e0",marginLeft:550 , borderRadius:50}}>

       
     
      <Grid container style={{margin:80}}>
        <Grid item xs={10}/>
        <Grid item xs={10} style={{marginTop:30}} >
        <center>
          <Card style={{marginRight:30, borderRadius:50}}>
              <CardContent>
              <Paper  style={{height:650, width:370,marginLeft:10, borderRadius:50}}>
                <h1>LOGIN PAGE</h1>
                <form onSubmit={this.handleLogin}>
                  <Grid container spacing={4}>
                      <Grid item xs={12}>
                      <center>
                      <CardMedia 
                         image={Apic2} style={{height:250,width:250,marginTop:30}}
                       />
                       </center>
                      </Grid>
                      <Grid item xs={12}>
                        <FormControl >
                        
                          <TextField type="text" helperText="Please enter your E-mail"  label="E-mail"  id="outlined-size-small" variant="outlined" backgroundColor="blue" size="small" name="username" value={this.state.username}
                            />
                            
                                 
                            
                        </FormControl>
                       {/* <Button variant="contained" color="primary" >Please Enter Your E-Mail address</Button>*/}
                      </Grid>
                      <Grid item xs={12}>
                        <FormControl>
                          <TextField type="password" helperText="Please enter password" label="Password"  id="outlined-size-small" variant="outlined" size="small" name="password" value={this.state.password}
                            />
                        </FormControl>
                      </Grid>
                      <Grid item xs={12}>
                        <FormControl>
                          <button style={style.button} >
                            <span><b>LOGIN</b></span>
                          </button>
                        </FormControl>
                        
                            
      
                      </Grid>
                  </Grid>
                  
                    <div>
                      <Typography color='error' variant="overline" display="block" gutterBottom>
                          <strong>{this.state.message}</strong>
                      </Typography>
                    </div>
                  
                </form>
                </Paper>
              </CardContent>
        </Card>
        </center>
        </Grid>
        <Grid item xs={5}/>
      </Grid>
      </Paper>
      </div>
    );
  }
}
                
 