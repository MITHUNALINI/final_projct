import React, { Component } from "react";
import { makeStyles } from '@material-ui/core/styles';
import TextField from '@material-ui/core/TextField';
import Grid from '@material-ui/core/Grid';
import { Card, CardContent, FormControl, Typography,InputLabel, NativeSelect, FormHelperText } from '@material-ui/core';
import Paper from '@material-ui/core/Paper';
import AddBoxIcon from '@material-ui/icons/AddBox';
import Button from '@material-ui/core/Button';
import SaveIcon from '@material-ui/icons/Save';
import ReplayIcon from '@material-ui/icons/Replay';
import FormatListBulletedIcon from '@material-ui/icons/FormatListBulleted';
import { Style } from '@material-ui/icons';
import CancelIcon from '@material-ui/icons/Cancel';
import './BuyNow.css';



const style = {
  root: {
    // minWidth: 275,
    backgroundColor:'#212121',
    marginTop: 50,
    color: '#e0f7fa'
  },
  button: {
    fontSize: '20px'
  },
}

export default class Mithu extends Component {
  constructor(props) {
    super(props);

    this.state = {
      Full_Name: "",
      Phone_Number: "",
      District: "",
      City: "",
      Address: "",
      successful: false
    };
  }

  onChangeTitle = (event) => {
    this.setState({
      Full_Name: event.target.value
    });
  }

  onChangeAuthor = (event) => {
    this.setState({
      Phone_Number: event.target.value
    });
  }

  onChangeCoverPhotoURL = (event) => {
    this.setState({
      District: event.target.value
    });
  }

  onChangeISBNNumber = (event) => {
    this.setState({
      City: event.target.value
    });
  }

  onChangePrice = (event) => {
    this.setState({
      Address: event.target.value
    });
  }


  handleAddBook = (event) => {
    event.preventDefault();

    if (this.state.Title && this.state.Author && this.state.CoverphotoURL && this.state.ISBNNumber && this.state.Price && this.state.SelectLangue && this.state.SelectGenre) {
      console.log(this.state.Title + " " + this.state.Author + " " + this.state.CoverphotoURL + "" +this.state.ISBNNumber + ""+ this.state.Price + "" + this.state.SelectLangue + "" + this.state.SelectGenre)
      this.setState({
        successful: true,
        message: "Success -Book Saved Successfully."
      })
    } else {
      this.setState({
        successful: false,
        message: "Not valied"
      })
    }
  }

  render() {
    return (
      // <div style={{margin:20,boxShadow:"10px 20px 25px black", border: "2px 5px 8px"}}>
        <Grid container spacing={1}>
        {/* <Grid item xs={4}/> */}
        <Grid item xs={7} style={{marginLeft:"20%",marginTop:"2%"}}>
          <Card className={style.root} style={{margin:20,boxShadow:"10px 20px 25px black", border: "2px 5px 8px"}}>
           <CardContent>
           {/* <Card variant="outlined"style={{height:600,width:1000,marginTop:"2%",marginLeft:0}}> */}
           <div className="card">
             <form  noValidate autoComplete="off" onSubmit={this.handleRegister}>
                  {!this.state.successful && (
             <Grid container spacing={1}>
                      <Grid item xs={11}>
                        
                            <h2 style={{fontSize:30,color:"#1a237e",fontFamily: 'Raleway'}}>Delivery Information</h2>
                          
                       
                      </Grid>
                      <Grid item xs={12}>
                        <FormControl>
                        <h4 style={{fontFamily: 'Raleway',color:"#64b5f6"}}>Full name</h4>
                        <TextField type="text"  variant="outlined" placeholder="Enter your first and last name" style={{width:430}} onChange={this.onChangeTitle} />
                        </FormControl>&emsp; &emsp; &emsp; 
                        

                        
                        <FormControl >
                        <h4 style={{fontFamily: 'Raleway',color:"#64b5f6"}}>Phone Number</h4>
                        <TextField type="text"  variant="outlined" placeholder="Please enter your phone number" style={{width:430}}onChange={this.onChangeCoverPhotoURL} />
                        </FormControl>
                        </Grid>
                         
                        <Grid item xs={12}>
                        <FormControl>
                        <h4 style={{fontFamily: 'Raleway' ,color:"#64b5f6"}}>District</h4>
                        <TextField type="text"  variant="outlined" placeholder="Please enter your district" style={{width:430}} onChange={this.onChangeAuthor} />
                        </FormControl>&emsp; &emsp; &emsp; 
                        
                      

                      
                        <FormControl>
                        <h4 style={{fontFamily: 'Raleway' ,color:"#64b5f6"}}>City</h4>
                        <TextField type="" variant="outlined" placeholder="Enter your city" style={{width:430}} onChange={this.onChange}/>
                        </FormControl>
                        </Grid>

                        <Grid item xs={12}>
                        <FormControl >
                        <h3 style={{fontFamily: 'Raleway' ,color:"#64b5f6"}}>Address</h3>
                        <TextField type="" variant="outlined" placeholder="Enter your Address" style={{width:430}} onChange={this.onChangeISBNNumber} />
                       </FormControl> &emsp; &emsp; &emsp; 

                       <FormControl >
                        <h3 style={{fontFamily: 'Raleway' ,color:"#64b5f6"}}>Email</h3>
                        <TextField type="" variant="outlined" placeholder="Enter your Email" style={{width:430}} onChange={this.onChangeISBNNumber} />
                       </FormControl> 

                       <br/>   <br/><br/>
                        

                        
                       
                        
                        
                      
                       
                        </Grid>
                       
                        <Button href="/Save" variant="contained"onClick={this.handleAddBook} style={{backgroundColor:'#fff176',width:150,marginLeft:500,alignItems:"right",color:"black"}}> <SaveIcon style={{fontSize:30}}/>Save</Button>&emsp; &emsp; 
                        <Button href="" variant="contained"onClick={this.handleAddBook} style={{backgroundColor:'#fff176',width:150,color:"black"}}> <CancelIcon style={{fontSize:20}}/>Cancel</Button>&emsp; &emsp; 
                       
                 </Grid>   
                 )}
                 
                
                </form>
                </div>
                {/* </Card> */}
              </CardContent>
        </Card>
        </Grid>
        <Grid item xs={4}/>
      </Grid>
      // </div>
    );
                            
}
}




                        


                        
     
        
        
        
     