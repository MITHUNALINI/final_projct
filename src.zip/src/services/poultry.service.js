import axios from 'axios';

const POULTRY_API_BASE_URL = 'http://localhost:8080/poultry';

class poultryservice {

    getAllPoultry() {
        return axios.get(POULTRY_API_BASE_URL);
    }
    createPoultry(product){
        return axios.post(POULTRY_API_BASE_URL , product);
    }
    getPoultryById(PoultryId) {
        console.log("getPoultryById");
        return axios.get(POULTRY_API_BASE_URL + '/' + PoultryId);
    }
    deletePoultry(PoultryId) {
        return axios.delete(POULTRY_API_BASE_URL + '/' + PoultryId);
    }
    updatePoultry(PoultryBody) {
        return axios.put(POULTRY_API_BASE_URL + '/' + PoultryBody.id,PoultryBody );
    }
    getAllPoultryInPage(pageNo,pageSize,sortBy){
        return axios.get(POULTRY_API_BASE_URL + '/' + 'page?pageNo='+pageNo+'&pageSize='+pageSize+'&sortBy='+sortBy );
    }
    searchPoultry(name){
        return axios.get(POULTRY_API_BASE_URL  + '?name='+name );
    }
    getPoultrytByPriceBB(minPrice,ratting){
        return axios.get(POULTRY_API_BASE_URL +  '?minPrice='+minPrice+'&ratting='+ratting );
    }

}

export default new poultryservice();

